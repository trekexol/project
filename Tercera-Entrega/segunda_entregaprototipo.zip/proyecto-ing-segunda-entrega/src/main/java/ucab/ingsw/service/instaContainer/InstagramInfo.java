package ucab.ingsw.service.instaContainer;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class InstagramInfo implements Serializable {
    private List<DataPackage> data;
}
